from robot import *

def test1():
    set_dt(100)
    select_jeu(1)

    # nb lignes: 11
    ###########################################################################################

def test2():
    set_dt(100)
    select_jeu(2)

    # nb lignes: 17
    
   

def test3():
    select_jeu(3)
    set_dt(100)

    # nb lignes: 7
    pass
    ###########################################################################################


test2()

base.mainloop()
