import socket, sys

HOST='0.0.0.0'
PORT=15550     

socket_serveur=socket.socket(socket.AF_INET, socket.SOCK_STREAM) # 1 - objet socket

try:
    socket_serveur.bind((HOST,PORT)) # 2 - associe socket à adr locale
except socket.error:
    print("liaison du socket à l'adr choisie a échoué")
    sys.exit


while True: 

    print("Serveur prêt, en attente de requête ...")
    socket_serveur.listen(2) # 3 - écoute les connexions entrantes
    
    conn_client, adr_client = socket_serveur.accept() # 4 - accepte une connexion
    print("Client connecté, adr IP {}, port {}".format(adr_client[0],adr_client[1]))
    
    msgServeur ="Bienvenue sur le serveur Marcel, entre tes coordonnées" # 5 - envoie des données
    conn_client.send(msgServeur.encode("Utf8"))

    while True:
        msgClient = conn_client.recv(1024).decode("Utf8") # 5 - reçoit des données
        j, i = int(msgClient[1]), int(msgClient[0])
        # ...
        
    
   

    conn_client.send("fin".encode("utf8"))
    print("Connexion interrompue")
    conn_client.close() # 6 - ferme la connexion

