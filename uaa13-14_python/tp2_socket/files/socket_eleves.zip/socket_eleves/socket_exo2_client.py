import socket, sys

HOST="localhost"
PORT=15550

# ... # 1 - objet socket

try:
    # ... # 2 - requête de connexion au serveur
except socket.error:
    print("La connexion a échoué.")
    sys.exit()
print("connexion établie avec le serveur")

# ...



print("Connexion interrompue.")
socket_client.close() # 4 - ferme la connexion
