import socket, sys

HOST="localhost"
PORT=15550

socket_client=socket.socket(socket.AF_INET, socket.SOCK_STREAM) # 1 - objet socket

try:
    socket_client.connect((HOST, PORT)) # 2 - requête de connexion au serveur
except socket.error:
    print("La connexion a échoué.")
    sys.exit()
print("connexion établie avec le serveur")

msgServeur = socket_client.recv(1024).decode("Utf8") # 3 - reçoit des données
print("S>", msgServeur)

while True:
    j = input("C> Jr Client entre j: ")
    i = input("C> Jr Client entre i: ")
    msgClient = j+i
    # ...


print("Connexion interrompue.")
socket_client.close() # 4 - ferme la connexion
