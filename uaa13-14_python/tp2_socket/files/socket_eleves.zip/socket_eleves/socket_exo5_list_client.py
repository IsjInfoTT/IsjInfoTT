import socket, sys

HOST="localhost"
PORT=15550
couleurs = ['rouge', 'vert', 'bleu', 'jaune', 'violet']

socket_client=socket.socket(socket.AF_INET, socket.SOCK_STREAM) # 1 - objet socket

try:
    socket_client.connect((HOST, PORT)) # 2 - requête de connexion au serveur
except socket.error:
    print("La connexion a échoué.")
    sys.exit()
print("connexion établie avec le serveur")

# ...


while True:
    
    # ...


print("Connexion interrompue.")
socket_client.close() # 4 - ferme la connexion
