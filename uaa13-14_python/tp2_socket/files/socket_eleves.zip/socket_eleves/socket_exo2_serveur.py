import socket, sys

HOST='0.0.0.0'
PORT=15550     

# ... # 1 - objet socket

try:
    # ... # 2 - associe socket à adr locale
except socket.error:
    print("liaison du socket à l'adr choisie a échoué")
    sys.exit


while True: 

    print("Serveur prêt, en attente de requête ...")
    # ... # 3 - écoute les connexions entrantes
    
    # ... # 4 - accepte une connexion
    print("Client connecté, adr IP {}, port {}".format(adr_client[0],adr_client[1]))
    
    # ...
    
   

    conn_client.send("fin".encode("utf8"))
    print("Connexion interrompue")
    conn_client.close() # 6 - ferme la connexion

