import socket, sys

HOST='0.0.0.0'
PORT=15550     
couleurs = ['rouge', 'vert', 'bleu', 'jaune', 'violet']

socket_serveur=socket.socket(socket.AF_INET, socket.SOCK_STREAM) # 1 - objet socket

try:
    socket_serveur.bind((HOST,PORT)) # 2 - associe socket à adr locale
except socket.error:
    print("liaison du socket à l'adr choisie a échoué")
    sys.exit


while True: 

    # ...

    while True:

        # ...   
    
   

    conn_client.send("fin".encode("utf8"))
    print("Connexion interrompue")
    conn_client.close() # 6 - ferme la connexion

